create table user
(userID varchar(20) not null,
username varchar(35) ,
gender Varchar(18) not null ,
designation Varchar(18) not null ,
Address Varchar(50) not null ,
Telephone varchar(18) not null ,
type varchar (20) not null,
email varchar(18) not null ,
DateOfBirth varchar(18) not null ,
primary key (userID));