insert into login values 
("U001", "kaushi", "97422","97422");