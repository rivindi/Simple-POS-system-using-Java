create table login
(UID varchar(10) not null,
username varchar(35) ,
uPassword Varchar(8) not null ,
conformPassword varchar(8) not null ,
primary key (UID));